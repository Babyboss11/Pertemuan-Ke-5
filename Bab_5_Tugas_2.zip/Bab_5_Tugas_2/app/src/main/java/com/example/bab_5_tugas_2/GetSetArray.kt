data class GetSetArray(
    var name: String = "",
    var detail: String = "",
    var pict: Int = 0
)